
package com.example.demo.controller;

import com.example.demo.model.Message;
import com.example.demo.repository.MessageRepository;
import com.example.demo.service.OpenSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class LandingController {

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private OpenSearchService openSearchService;

    @GetMapping("/")
    public String landingPage(Model model) {
        model.addAttribute("messages", messageRepository.findAll());
        return "landing";
    }

    @PostMapping("/add")
    public String addMessage(@RequestParam String name, @RequestParam String content) {
        Message msg = new Message();
        msg.setName(name);
        msg.setContent(content);
        messageRepository.save(msg);
        return "redirect:/";
    }

    @PostMapping("/load")
    public String loadToOpenSearch() {
        openSearchService.loadData(messageRepository.findAll());
        return "redirect:/";
    }

    @PostMapping("/clear")
    public String clearOpenSearch() {
        openSearchService.clearData();
        return "redirect:/";
    }
}
