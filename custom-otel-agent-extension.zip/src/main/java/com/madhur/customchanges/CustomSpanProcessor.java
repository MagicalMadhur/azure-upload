
package com.madhur.customchanges;

import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.context.Context;
import io.opentelemetry.sdk.trace.ReadWriteSpan;
import io.opentelemetry.sdk.trace.ReadableSpan;
import io.opentelemetry.sdk.trace.SpanProcessor;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class CustomSpanProcessor implements SpanProcessor {

    @Override
    public void onStart(Context parentContext, ReadWriteSpan span) {
        span.setAttribute(AttributeKey.stringKey("custom.thread_name"), Thread.currentThread().getName());

        String authHeader = span.getAttribute(AttributeKey.stringKey("http.request.header.authorization"));
        if (authHeader != null) {
            String decoded = decodeAuthInfo(authHeader);
            span.setAttribute(AttributeKey.stringKey("custom.auth_info"), decoded);
        }

        StackTraceElement[] stack = Thread.currentThread().getStackTrace();
        if (stack.length > 2) {
            StackTraceElement elem = stack[2];
            span.setAttribute(AttributeKey.stringKey("custom.method_name"), elem.getMethodName());
            span.setAttribute(AttributeKey.stringKey("custom.class_name"), elem.getClassName());
            span.setAttribute(AttributeKey.stringKey("custom.file_name"), elem.getFileName());
            span.setAttribute(AttributeKey.longKey("custom.line_number"), elem.getLineNumber());
        }
    }

    @Override
    public void onEnd(ReadableSpan span) {
        // Optional: add logic if needed
    }

    @Override
    public boolean isStartRequired() {
        return true;
    }

    @Override
    public boolean isEndRequired() {
        return false;
    }

    private String decodeAuthInfo(String authorization) {
        try {
            String[] parts = authorization.split("\.");
            if (parts.length == 3) {
                return new String(Base64.getUrlDecoder().decode(parts[1]), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "";
        }
        return "";
    }
}
